import React, {
    useEffect,
    useState
} from "react";

import {
    StyleSheet,
    Text,
    View
} from "react-native";

import {
    SafeAreaView
} from "react-native-safe-area-context";

import { Game } from "../core/Game";
import { Seat } from "../core/Seat";
import { Suit } from "../cards/Card";
import { Contract } from "../play/Contract";

import HandView from "./HandView";
import SeatView from "./SeatView";
import TableCenter from "./TableCenter";

export default function BridgeTable() {
    const [game] = useState(
        () =>
            new Game(
                new Contract(
                    4,
                    Suit.Spades,
                    Seat.South
                ),
                Seat.West
            )
    );

    const [refresh, setRefresh] =
        useState(0);

    /*
     * Play one computer card at a time.
     *
     * The delay allows the active-seat indicator
     * and played cards to remain visible.
     */
const timer = setTimeout(() => {

    const played =
        game.playComputerTurn();

    if (!played) {

        return;
    }

    setRefresh(
        value => value + 1
    );

}, 650);

useEffect(() => {
    if (
        game.isFinished() ||
        game.currentSeat === Seat.South
    ) {
        return;
    }

    const timer = setTimeout(() => {
        /*
         * Check again because the turn may have
         * changed while the timer was waiting.
         */
        if (
            game.isFinished() ||
            game.currentSeat === Seat.South
        ) {
            return;
        }

        const played =
            game.playComputerTurn();

        if (!played) {
            return;
        }

        setRefresh(
            value => value + 1
        );
    }, 650);

    return () => {
        clearTimeout(timer);
    };
}, [game, refresh]);

    function playSouthCard(
        index: number
    ): void {
        if (game.isFinished()) {
            return;
        }

        if (
            game.currentSeat !==
            Seat.South
        ) {
            return;
        }

        const hand =
            game.handOf(Seat.South);

        const card =
            hand.cards[index];

        if (!card) {
            return;
        }

        const currentTrick =
            game.table.currentTrick;

        const leadSuit =
            currentTrick.cards.length > 0
                ? currentTrick.cards[0]
                    .card.suit
                : undefined;

        if (leadSuit !== undefined) {
            const mustFollowSuit =
                hand.cards.some(
                    currentCard =>
                        currentCard.suit ===
                        leadSuit
                );

            if (
                mustFollowSuit &&
                card.suit !== leadSuit
            ) {
                return;
            }
        }

        const successfullyPlayed =
            game.playCard(
                Seat.South,
                card
            );

        if (!successfullyPlayed) {
            return;
        }

        setRefresh(
            value => value + 1
        );
    }

    const currentTrick =
        game.table.currentTrick;

    const leadSuit =
        currentTrick.leadSuit;

    const southCanPlay =
        game.currentSeat === Seat.South &&
        !game.isFinished();

    const gameMessage =
        game.isFinished()
            ? "Hand complete"
            : southCanPlay
              ? "Your turn — choose a highlighted card"
              : `${game.currentSeat} is playing`;

    return (
        <SafeAreaView style={styles.safeArea}>
            <View style={styles.container}>
                <View style={styles.headerRow}>
                    <View style={styles.titleArea}>
                        <Text style={styles.header}>
                            BridgeAI
                        </Text>

                        <Text style={styles.contract}>
                            Contract: 4♠ by South
                        </Text>
                    </View>

                    <View style={styles.scorePanel}>
                        <Text style={styles.score}>
                            NS {game.table.nsTricks}
                        </Text>

                        <Text style={styles.score}>
                            EW {game.table.ewTricks}
                        </Text>
                    </View>
                </View>

                <View style={styles.northRow}>
                    <SeatView
                        name="North"
                        cardCount={
                            game.handOf(
                                Seat.North
                            ).cards.length
                        }
                        orientation="horizontal"
                        active={
                            game.currentSeat ===
                            Seat.North
                        }
                    />
                </View>

                <View style={styles.middleRow}>
                    <View style={styles.sideSeat}>
                        <SeatView
                            name="West"
                            cardCount={
                                game.handOf(
                                    Seat.West
                                ).cards.length
                            }
                            orientation="vertical"
                            active={
                                game.currentSeat ===
                                Seat.West
                            }
                        />
                    </View>

                    <View style={styles.centerTable}>
                        <TableCenter
                            trick={currentTrick}
                        />
                    </View>

                    <View style={styles.sideSeat}>
                        <SeatView
                            name="East"
                            cardCount={
                                game.handOf(
                                    Seat.East
                                ).cards.length
                            }
                            orientation="vertical"
                            active={
                                game.currentSeat ===
                                Seat.East
                            }
                        />
                    </View>
                </View>

                <View style={styles.southArea}>
                    <View style={styles.southHeading}>
                        <Text style={styles.you}>
                            South — You
                        </Text>

                        <Text style={styles.cardCount}>
                            {
                                game.handOf(
                                    Seat.South
                                ).cards.length
                            }{" "}
                            cards
                        </Text>
                    </View>

                    <Text style={styles.turnMessage}>
                        {gameMessage}
                    </Text>

                    <HandView
                        hand={
                            game.handOf(
                                Seat.South
                            )
                        }
                        leadSuit={leadSuit}
                        enabled={southCanPlay}
                        onCardPlayed={
                            playSouthCard
                        }
                    />
                </View>
            </View>
        </SafeAreaView>
    );
}

const styles = StyleSheet.create({
safeArea: {
    flex: 1,
    backgroundColor: "#145A32"
},

container: {
    flex: 1,
    backgroundColor: "#1B7040",
    paddingHorizontal: 8,
    paddingTop: 6,
    paddingBottom:
        Platform.OS === "android"
            ? 28
            : 8
},

northRow: {
    height: 88,
    alignItems: "center",
    justifyContent: "center"
},

middleRow: {
    flex: 1,
    minHeight: 190,
    width: "100%",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between"
},

southArea: {
    width: "100%",
    alignItems: "center",
    paddingTop: 2,
    paddingBottom: 8
},

    headerRow: {
        flexDirection: "row",
        justifyContent: "space-between",
        alignItems: "flex-start",
        paddingHorizontal: 6
    },

    titleArea: {
        flexShrink: 1
    },

    header: {
        color: "#FFFFFF",
        fontSize: 26,
        fontWeight: "bold",
        includeFontPadding: false
    },

    contract: {
        color: "#E8F5E9",
        fontSize: 14,
        marginTop: 2
    },

    scorePanel: {
        backgroundColor:
            "rgba(0,0,0,0.22)",
        borderRadius: 9,
        paddingHorizontal: 12,
        paddingVertical: 6,
        minWidth: 58
    },

    score: {
        color: "#FFFFFF",
        fontSize: 14,
        fontWeight: "700",
        textAlign: "right"
    },

    northRow: {
        height: 100,
        alignItems: "center",
        justifyContent: "center"
    },

    middleRow: {
        flex: 1,
        minHeight: 220,
        width: "100%",
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "space-between"
    },

    sideSeat: {
        width: 72,
        alignItems: "center",
        justifyContent: "center",
        zIndex: 2
    },

    centerTable: {
        flex: 1,
        alignItems: "center",
        justifyContent: "center",
        paddingHorizontal: 2
    },

    southArea: {
        width: "100%",
        alignItems: "center",
        paddingTop: 5
    },

    southHeading: {
        width: "100%",
        maxWidth: 340,
        flexDirection: "row",
        justifyContent: "space-between",
        alignItems: "center",
        marginBottom: 3,
        paddingHorizontal: 3
    },

    you: {
        color: "#FFFFFF",
        fontSize: 18,
        fontWeight: "bold"
    },

    cardCount: {
        color: "#E8F5E9",
        fontSize: 13
    },

    turnMessage: {
        color: "#FFFFFF",
        fontSize: 14,
        fontWeight: "600",
        marginBottom: 7
    }
});